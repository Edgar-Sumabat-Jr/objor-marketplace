from . import views
from django.urls import path

app_name = "marketplace"

urlpatterns = [path("", views.index, name="index")]
